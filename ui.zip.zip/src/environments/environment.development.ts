export const environment = {
  production: false,
  PRODUCT_URL : 'http://18.209.224.13:8082/api/products/',
  ORDER_URL : 'http://18.209.224.13:8081/api/orders/'
};
