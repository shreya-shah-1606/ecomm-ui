export const environment = {
   production: true,
   PRODUCT_URL : 'http://44.211.30.101:8082/api/products/',
};
