import { HttpClient } from '@angular/common/http';
import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-home-page',
  templateUrl: './home-page.component.html',
  styleUrls: ['./home-page.component.css']
})
export class HomePageComponent implements OnInit {

  rowData: any; // Initilized 'rowData' variable to store data

  constructor(private http: HttpClient) {  } // Injecting HttpClient into the constructor in a private property called http.

  columnDefs = [
    {headerName: 'Item Name', field: 'itemname' },
    {headerName: 'Quantity', field: 'quantity' },
    {headerName: 'Price / Quantity', field: 'price'}
  ];

  //Added ngOnInit funtion
  ngOnInit() {
    this.http.get('https://raw.githubusercontent.com/monishnarendra/Angular-Ag-Grid-Quick-Start-Example/master/my-sample/Data.json').subscribe(
      data => this.rowData = data
    );
  }

}
