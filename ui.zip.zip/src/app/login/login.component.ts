import { Component } from '@angular/core';
import { Router } from '@angular/router';

@Component({
  selector: 'app-login',
  templateUrl: './login.component.html',
  styleUrls: ['./login.component.css']
})
export class LoginComponent  {

   username: string = '';
   password: string = '';
   isAuthenticated: boolean = false;

  constructor(private router: Router) {}

  public onSubmit(): void {
    // TODO: Add authentication logic here
    if(this.username == 'admin' && this.password== 'admin'){
       this.isAuthenticated = true;
    }

    if (this.isAuthenticated) {
      this.router.navigate(['/home']);
    }
  }

}
